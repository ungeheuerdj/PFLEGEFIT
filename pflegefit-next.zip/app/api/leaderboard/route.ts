import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export async function GET(req: Request){
  try{
    const { searchParams } = new URL(req.url);
    const start = searchParams.get('start');
    const end = searchParams.get('end');
    if(!start || !end) return NextResponse.json({ error:'start and end required' }, { status:400 });

    const url = process.env.NEXT_PUBLIC_SUPABASE_URL as string;
    const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string;
    if(!url || !anon) return NextResponse.json({ data: [] });

    const supabase = createClient(url, anon);
    const { data, error } = await supabase
      .from('daily_attempts')
      .select('username, score, created_at, challenge_date, user_id')
      .gte('challenge_date', start)
      .lte('challenge_date', end);

    if(error) return NextResponse.json({ error: error.message }, { status:500 });
    return NextResponse.json({ data });
  }catch(e){
    return NextResponse.json({ error:'unexpected error' }, { status:500 });
  }
}
