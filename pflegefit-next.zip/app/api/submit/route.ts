import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export async function POST(req: Request){
  try{
    const { username, score, date, seed } = await req.json();
    if(!username || typeof score!=='number' || !date) return NextResponse.json({ error:'invalid payload' }, { status:400 });

    const url = process.env.NEXT_PUBLIC_SUPABASE_URL as string;
    const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string;
    if(!url || !anon) return NextResponse.json({ error:'supabase env missing' }, { status:500 });

    const supabase = createClient(url, anon);
    const { error } = await supabase.from('daily_attempts').insert({ username, score, challenge_date: date, seed });
    if(error){
      if((error as any).code==='23505') return NextResponse.json({ error:'already submitted today' }, { status:409 });
      return NextResponse.json({ error: error.message }, { status:500 });
    }
    return NextResponse.json({ ok:true }, { status:201 });
  }catch(e){
    return NextResponse.json({ error:'unexpected error' }, { status:500 });
  }
}
