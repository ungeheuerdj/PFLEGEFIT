# PflegeFit (Next.js)
Deploy-Quickstart:
1) Repo nach GitHub pushen
2) In Vercel importieren
3) Environment Variables setzen:
   - NEXT_PUBLIC_SUPABASE_URL
   - NEXT_PUBLIC_SUPABASE_ANON_KEY
4) Deploy. Auf dem Handy URL öffnen, "Zum Startbildschirm hinzufügen".
